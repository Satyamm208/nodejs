var router=require("express").Router();
const res = require("express/lib/response");
const Student = require("../models/Student");
var Book=require("../models/Student");
module.exports=router;


router.get("/list",(req,res)=>{
	Book.find(function (err, students) {
  		if (err) return console.error(err);
  		console.log(students);
    	res.render("list",{students:students});
	})
})

router.get("/add",(req,res)=>{
	res.render("add");
})
router.post("/save",(req,res)=>{
	//INSERT	
	console.log(req.body)
	var student2 = new Student({
            name : req.body.name,
            roll : req.body.roll,
            email : req.body.email,
            address:req.body.address
        }); 
	student2.save(function (err, student) {
	      if (err) return console.error(err);
	      id=student._id;
	      console.log(student._id + " saved to student collection.");	 
	      res.redirect("/students/list");
	      //res.send(book._id + " saved to books collection.")
    }); 

});
router.get("/delete/:id",(req,res)=>{
	Student.findOneAndRemove({"_id":req.params.id},
	 function (err, student) {
        if (err) return res.status(500).send(
        	"There was a problem deleting.");
		res.redirect("/students/list");
    });

});
router.get("/edit/:id",(req,res)=>{
	Student.findById({"_id":req.params.id}, function (err, student) 
	{
        if (err) return res.status(500).send(
        	"There was a problem finding.");
        if (!student) return res.status(404).send(
        	"No data found.");
		res.render("edit",{student: student});
    });

})
router.post("/update",(req,res)=>{
    Student.findOneAndUpdate({"_id":req.body._id}, 
		{
			 name : req.body.name,
 			roll : req.body.roll,
 			email : req.body.email,
 			address:req.body.address
		}, 
    	{new: true}, function (err, student) {
        if (err) return res.status(500).send(
        	"There was a problem updating.");
        res.redirect("/students/list");
    });

})
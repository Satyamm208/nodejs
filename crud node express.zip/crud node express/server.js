var express=require('express');
var app=express();
require('dotenv').config()
var cors=require("cors")
var StudentRoute=require("./routes/StudentRoute")

app.set('view engine','ejs');
app.use(express.urlencoded({extended:true}));
app.use("/students",StudentRoute)
//http://localhost:8080/students
app.listen(8080);
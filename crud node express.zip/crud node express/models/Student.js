var mongoose=require("../config/db");
var StudentSchema=mongoose.Schema({
    name:String,
    roll:Number,
    email:String,
    address:String
});

var Student=mongoose.model('Student',StudentSchema,"students");
module.exports=Student;


// var mongoose=require("../config/db");
//SCHEMA
// var BookSchema = mongoose.Schema({
    // name: String,
    // price: Number,
    // quantity: Number
//   }); 
// var Book = mongoose.model('Book', BookSchema, "books"); //MODEL
// module.exports=Book;